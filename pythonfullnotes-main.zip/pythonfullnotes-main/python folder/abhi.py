def welcome():
    print("You are welcome from abhi")
if __name__=="__main__":
    welcome()