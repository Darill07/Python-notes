#44 lecture
import math
result=math.sqrt(10)
print(result)
a=math.floor(3.45)
print(a)

#Example 2
import math as m
a=m.sqrt(9)
print(a)

#Example 3
import math
print(dir(math))

#45 lecture
import abhi     #abhi name python file created
abhi.welcome()

#46 lecture
#there in os documentation