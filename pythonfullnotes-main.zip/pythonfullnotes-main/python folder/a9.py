#Explicit Type Conversion

a="1"
b="2"

print(int(a) +int(b))

#implicit type conversion
a=1
b=2.9
print(a+b)