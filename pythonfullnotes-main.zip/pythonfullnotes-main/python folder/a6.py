a=12333333
print(a)
b="Abhi & Rushi"
print(b)
#to concatenate use , symbol instead of plus
print(a,b)

#to what data type is used use like this

print("The type of a is:",type(a))
print("The type of b is",type(b))

#usage odf types of variables
a1=1
b1=True
c1="Abhi"
d1=None
e1=complex(2,3)


print("The type of a1 is:",type(a1))
print("The type of b1 is",type(b1))
print("The type of c1 is",type(c1))
print("The type of d1 is",type(d1))
print(e1)

#Sequenced data list,tupple
list1 = [2,3.4,[4,8],["apple","bannana"]]
print(list1)

tuple1 = (("parrot","sparrow"),("Lion","Tiger"))
print(tuple1)

#Mapped data:dict
dict1 ={"name":"Sakshi", "age":20,"canVote":True}
print(dict1)