print(5+6)
print(5-3)
print(5*3)
print(5/3)
print(5//3) #Floor Division
print(2**3) #Exponential Value
print(5%3) #Modulo Operator