#short hand if else statement
#it is not suitable for complex logic
a=300
b=3300
print("A") if a>b else print("=") if a==b else print("B")

#42 lecture
marks=[2,3,40,99,93,37,63]
for index,mark in enumerate(marks):
    print(mark)
    if(index==3):
        print("Awesome")
        
#43 lecture
