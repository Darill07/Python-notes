#54 lecture
a=3
b=3
print(a is b)
print(a==b)
c=[23,34,45]
d=[23,34,45]
print(c is d)
print(c==d)
