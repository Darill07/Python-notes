#while loop usage Example 1
# i = 0
# while(i<=3):
#     print(i)
#     i=i+1
    
#Example 2 of while loop
# count = 5
# while(count>0):
#     print(count)
#     count=count-1
    
#Example 3   
# count = 5
# while(count>0):
#     print(count)
#     count=count-1
# else:
#     print("Done with the code")
    
#How to emulate do while loop in python
i=1
while True:
    print(i)
    i=i+1
    if(i>3):
        break



    
