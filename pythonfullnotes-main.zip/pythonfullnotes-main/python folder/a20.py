#function usage with example 
def calculateGmean(a,b):
    mean =(a*b)/(a+b)
    print(mean)

a=20
b=30
calculateGmean(a,b)

c=30
d=40
calculateGmean(c,d)

#Calling a function
def name(fname,lname):
    print("Hello,",fname,lname)
name("Abhi","Rushi")

