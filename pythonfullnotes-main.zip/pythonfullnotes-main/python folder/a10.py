a=input("Enter your name:")
print("My Name is",a)


#this video is 11th
print('good"bye"')
ab='''
vnkldf;avlkanbkl andlk;b nakjvnlk;nl
'''
print(ab)
name="Abhi"
print(name[0])

#Usage of for loop
print("For loop usage")
for character in name:
 print(character)