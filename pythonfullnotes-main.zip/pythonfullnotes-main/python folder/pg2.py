print("Hello",7)
print(5)
print("H",7,8)
print(7/8)
print("Hello \nGood")
# the hashtag used to comment the line
#starting of a line is called block comment

print(2+3) #this is a inline comment

'''dnnsn
cscn
'''

print('Good\"good day\"')
print("Hi",6,7)

#Usage of separator

print("Hi",6,7,sep="[")

#end parameter usage
print("Hi",4,5,end="123")  #end is used to end the given statment with specified end value
print("Hello")

#end with b ackslash n
print("Hi",1,2,end="33\n")
print("Bye")